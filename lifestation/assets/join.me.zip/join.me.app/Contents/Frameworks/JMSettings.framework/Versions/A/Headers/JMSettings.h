//
//  JMSettings.h
//  JMSettings
//
//  Created by thonfi on 07/04/15.
//  Copyright (c) 2015 LogMeIn, Inc. All rights reserved.
//

#ifndef JMSettings_JMSettings_h
#define JMSettings_JMSettings_h

#import <CoreFoundation/CoreFoundation.h>

#import <JMSettings/JMSLogger.h>
#import <JMSettings/JMSSettingsConfig.h>
#import <JMSettings/JMSSettings.h>

#endif // JMSettings_JMSettings_h
